import "./HeroBanner.css";

import heroImage from "../../assets/hero.png";

interface HeroBannerProps {
  firstName: string;
}

export default function HeroBanner({
  firstName,
}: HeroBannerProps) {

  const today = new Date();

  const date = today.toLocaleDateString(
    "fr-FR",
    {
      weekday: "long",
      day: "numeric",
      month: "long",
    }
  );

  const hour = today.getHours();

  let greeting = "Bonsoir";

  if (hour < 12) {
    greeting = "Bonjour";
  } else if (hour < 18) {
    greeting = "Bon après-midi";
  }

  return (

    <section className="heroBanner">

      <div className="heroBanner__content">

        <span className="heroBanner__date">
          {date}
        </span>

        <h1 className="heroBanner__title">

          {greeting}

          <span>

            {" "}
            {firstName} 💚

          </span>

        </h1>

        <p className="heroBanner__subtitle">

          Chaque petite victoire te rapproche
          de la meilleure version de toi.

        </p>

        <div className="heroBanner__buttons">

          <button className="heroBanner__primary">

            Continuer ma journée

          </button>

          <button className="heroBanner__secondary">

            Voir mes objectifs

          </button>

        </div>

      </div>

      <div className="heroBanner__image">

        <img
          src={heroImage}
          alt="Welcome To The Good Life"
        />

      </div>

    </section>

  );

}      <div className="heroBanner__floating">

        <div className="heroCard heroCard--workout">

          <span className="heroCard__icon">🏋️</span>

          <div>

            <small>Séance du jour</small>

            <strong>Prêt à performer</strong>

          </div>

        </div>

        <div className="heroCard heroCard--water">

          <span className="heroCard__icon">💧</span>

          <div>

            <small>Hydratation</small>

            <strong>Objectif 2,5 L</strong>

          </div>

        </div>

        <div className="heroCard heroCard--mood">

          <span className="heroCard__icon">🔥</span>

          <div>

            <small>Motivation</small>

            <strong>Tu es sur une bonne lancée</strong>

          </div>

        </div>

      </div>