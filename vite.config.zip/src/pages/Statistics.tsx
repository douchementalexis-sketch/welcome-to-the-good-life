import BottomNavigation from "../components/BottomNavigation";

export default function Statistics() {
  return (
    <div className="home">
      <h1>📊 Statistiques</h1>

      <p>Les statistiques arriveront bientôt.</p>

      <BottomNavigation />
    </div>
  );
}